const jwt = require('jsonwebtoken')
const config = require('../config')
const { fail } = require('../utils/response')

/**
 * 验证 JWT access_token
 */
function verifyToken(req, res, next) {
  // 支付回调跳过
  if (req.path === '/pay-callback') return next()

  const authHeader = req.headers.authorization
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json(fail('未登录，请先授权'))
  }

  const token = authHeader.slice(7)
  try {
    const decoded = jwt.verify(token, config.jwt.secret)
    req.user = decoded  // { userId, merchantId, role, type }
    next()
  } catch (err) {
    return res.status(401).json(fail('Token 已过期，请重新登录'))
  }
}

/**
 * 验证商家身份
 */
function verifyMerchant(req, res, next) {
  if (!req.user || req.user.role !== 'merchant') {
    return res.status(403).json(fail('无权限，仅商家可操作'))
  }
  next()
}

/**
 * 生成 access_token
 */
function signAccessToken(payload) {
  return jwt.sign(payload, config.jwt.secret, { expiresIn: config.jwt.accessExpires })
}

/**
 * 生成 refresh_token
 */
function signRefreshToken(payload) {
  return jwt.sign(payload, config.jwt.secret, { expiresIn: config.jwt.refreshExpires })
}

module.exports = { verifyToken, verifyMerchant, signAccessToken, signRefreshToken }
