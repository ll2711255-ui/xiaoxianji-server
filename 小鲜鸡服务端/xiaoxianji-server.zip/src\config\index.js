require('dotenv').config({ path: require('path').join(__dirname, '..', '..', '.env') })

module.exports = {
  port: parseInt(process.env.PORT) || 3000,
  mongodbUri: process.env.MONGODB_URI || 'mongodb://localhost:27017/xiaoxianji',
  jwt: {
    secret: process.env.JWT_SECRET || 'xiaoxianji_dev_secret',
    accessExpires: process.env.JWT_ACCESS_EXPIRES || '2h',
    refreshExpires: process.env.JWT_REFRESH_EXPIRES || '7d'
  },
  wechat: {
    mchid: process.env.WECHAT_MCHID || '',
    serialNo: process.env.WECHAT_SERIAL_NO || '',
    apiV3Key: process.env.WECHAT_APIv3_KEY || '',
    privateKeyPath: process.env.WECHAT_PRIVATE_KEY_PATH || '',
    appId: process.env.WECHAT_APPID || '',
    appSecret: process.env.WECHAT_APPSECRET || ''
  },
  upload: {
    dir: process.env.UPLOAD_DIR || 'uploads',
    maxFileSize: parseInt(process.env.MAX_FILE_SIZE) || 5 * 1024 * 1024
  }
}
