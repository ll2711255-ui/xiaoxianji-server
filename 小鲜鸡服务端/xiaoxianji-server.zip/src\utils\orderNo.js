const Counter = require('../models/Counter')

/**
 * 生成唯一订单号（原子递增）
 * 格式：字母 A-Z 循环 + 5位数字，如 A00001 → A99999 → B00000
 * 通过 MongoDB 事务保证并发安全
 */
async function generateOrderNo(prefix = 'ORD') {
  const session = await Counter.startSession()
  try {
    session.startTransaction()
    let counter = await Counter.findById('order').session(session)
    if (!counter) {
      counter = new Counter({ _id: 'order', letterIdx: 0, seq: 0 })
    }
    let { letterIdx, seq } = counter
    seq += 1
    if (seq > 99999) {
      letterIdx = (letterIdx + 1) % 26
      seq = 0
    }
    counter.letterIdx = letterIdx
    counter.seq = seq
    await counter.save({ session })
    await session.commitTransaction()
    const letter = String.fromCharCode(65 + letterIdx)
    return prefix + letter + String(seq).padStart(5, '0')
  } catch (err) {
    await session.abortTransaction()
    throw err
  } finally {
    session.endSession()
  }
}

module.exports = { generateOrderNo }
