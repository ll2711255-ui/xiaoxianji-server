/**
 * 微信支付 APIv3 — JSAPI 下单 + 回调验签
 * 从 cloud function payHelper.js 移植
 */
const crypto = require('crypto')
const https = require('https')
const fs = require('fs')
const config = require('../config')

// 从环境变量或文件加载私钥
function getPrivateKey() {
  if (config.wechat.privateKeyPath && fs.existsSync(config.wechat.privateKeyPath)) {
    return fs.readFileSync(config.wechat.privateKeyPath, 'utf8')
  }
  return ''
}

/**
 * 构建 WECHATPAY2-SHA256-RSA2048 Authorization 头
 */
function buildAuth(method, urlPath, body) {
  const ts = Math.floor(Date.now() / 1000).toString()
  const nonce = crypto.randomBytes(16).toString('hex')
  const msg = method + '\n' + urlPath + '\n' + ts + '\n' + nonce + '\n' + (body || '') + '\n'
  const privateKey = getPrivateKey()
  const sig = crypto.createSign('RSA-SHA256').update(msg).sign(privateKey, 'base64')
  return `WECHATPAY2-SHA256-RSA2048 mchid="${config.wechat.mchid}",nonce_str="${nonce}",timestamp="${ts}",serial_no="${config.wechat.serialNo}",signature="${sig}"`
}

/**
 * 发起 APIv3 请求
 */
function v3Request(method, path, body) {
  return new Promise((resolve, reject) => {
    const bodyStr = body ? JSON.stringify(body) : ''
    const req = https.request({
      hostname: 'api.mch.weixin.qq.com',
      path,
      method,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': buildAuth(method, path, bodyStr),
        'User-Agent': 'XiaoXianJi/1.0'
      }
    }, (res) => {
      let chunks = []
      res.on('data', c => chunks.push(c))
      res.on('end', () => {
        const raw = Buffer.concat(chunks).toString('utf8')
        try { resolve({ status: res.statusCode, data: JSON.parse(raw) }) }
        catch (_) { resolve({ status: res.statusCode, data: raw }) }
      })
    })
    req.on('error', reject)
    if (bodyStr) req.write(bodyStr)
    req.end()
  })
}

/**
 * 生成 wx.requestPayment 参数
 */
function buildPayParams(prepayId, appId) {
  const nonceStr = crypto.randomBytes(16).toString('hex')
  const timeStamp = Math.floor(Date.now() / 1000).toString()
  const pkg = 'prepay_id=' + prepayId
  const msg = appId + '\n' + timeStamp + '\n' + nonceStr + '\n' + pkg + '\n'
  const privateKey = getPrivateKey()
  const paySign = crypto.createSign('RSA-SHA256').update(msg).sign(privateKey, 'base64')
  return { timeStamp, nonceStr, package: pkg, signType: 'RSA', paySign }
}

module.exports = { v3Request, buildPayParams }
