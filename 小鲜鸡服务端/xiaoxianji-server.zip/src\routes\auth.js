const router = require('express').Router()
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const config = require('../config')
const Merchant = require('../models/Merchant')
const User = require('../models/User')
const { signAccessToken, signRefreshToken } = require('../middleware/auth')
const { success, fail } = require('../utils/response')

// 商家登录
router.post('/merchant-login', async (req, res) => {
  try {
    const { username, password, phone } = req.body
    const identifier = username || phone
    if (!identifier || !password) {
      return res.json(fail('请输入账号和密码'))
    }

    const merchant = await Merchant.findOne({
      $or: [{ username: identifier }, { phone: identifier }]
    })
    if (!merchant) {
      return res.json(fail('账号或密码错误'))
    }

    const valid = await bcrypt.compare(password, merchant.password)
    if (!valid) {
      return res.json(fail('账号或密码错误'))
    }

    const payload = { merchantId: merchant._id.toString(), role: 'merchant', type: 'merchant' }
    const accessToken = signAccessToken(payload)
    const refreshToken = signRefreshToken(payload)

    res.json(success({
      accessToken,
      refreshToken,
      merchantId: merchant._id.toString(),
      role: merchant.role,
      name: merchant.name
    }))
  } catch (err) {
    console.error('登录失败:', err)
    res.status(500).json(fail('登录失败'))
  }
})

// 刷新 token
router.post('/refresh-token', async (req, res) => {
  try {
    const { refreshToken } = req.body
    if (!refreshToken) {
      return res.status(401).json(fail('缺少 refresh_token'))
    }

    const decoded = jwt.verify(refreshToken, config.jwt.secret)
    const payload = {
      merchantId: decoded.merchantId,
      userId: decoded.userId,
      role: decoded.role,
      type: decoded.type
    }

    const newAccessToken = signAccessToken(payload)
    const newRefreshToken = signRefreshToken(payload)

    res.json(success({ accessToken: newAccessToken, refreshToken: newRefreshToken }))
  } catch (err) {
    res.status(401).json(fail('Token 已过期，请重新登录'))
  }
})

// 微信登录
router.post('/wx-login', async (req, res) => {
  try {
    const { code, nickname, avatarUrl } = req.body
    if (!code) {
      return res.json(fail('缺少登录凭证'))
    }

    // TODO: 调微信 code2Session 获取 openid
    // 开发阶段直接 mock
    const openid = 'mock_openid_' + (code.slice(-8) || Date.now())

    let user = await User.findOne({ openid })
    if (!user) {
      user = new User({ openid, nickname: nickname || '微信用户', avatarUrl: avatarUrl || '' })
      await user.save()
    } else {
      if (nickname) user.nickname = nickname
      if (avatarUrl) user.avatarUrl = avatarUrl
      await user.save()
    }

    const payload = { userId: user._id.toString(), openid, role: 'user', type: 'user' }
    const accessToken = signAccessToken(payload)
    const refreshToken = signRefreshToken(payload)

    res.json(success({
      accessToken,
      refreshToken,
      userId: user._id.toString(),
      nickname: user.nickname,
      avatarUrl: user.avatarUrl
    }))
  } catch (err) {
    console.error('微信登录失败:', err)
    res.status(500).json(fail('登录失败'))
  }
})

// 微信手机号
router.post('/wx-phone', async (req, res) => {
  try {
    const { code, phoneCode } = req.body
    // TODO: 调微信 getPhoneNumber 接口
    // 开发阶段直接存储
    const phone = code || phoneCode || ''
    if (req.user && req.user.userId) {
      await User.findByIdAndUpdate(req.user.userId, { phone })
    }
    res.json(success({ phone }))
  } catch (err) {
    res.status(500).json(fail('获取手机号失败'))
  }
})

module.exports = router
