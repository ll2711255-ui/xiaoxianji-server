const router = require('express').Router()
const Order = require('../models/Order')
const { success, fail } = require('../utils/response')

/**
 * 微信支付回调
 * POST /api/pay-callback
 * 需要验签 Wechatpay-Signature（TODO）
 */
router.post('/', async (req, res) => {
  try {
    const { id, out_trade_no, trade_state } = req.body

    console.log('[支付回调]', JSON.stringify(req.body))

    if (trade_state === 'SUCCESS') {
      const order = await Order.findOne({ orderNo: out_trade_no })
      if (!order) {
        return res.status(200).json({ code: 'FAIL', message: '订单不存在' })
      }
      if (order.status === 'pending') {
        order.status = 'paid'
        order.payTime = new Date()
        order.addTimeline('paid')
        await order.save()
      }
    }

    // 微信要求返回 200
    res.status(200).json({ code: 'SUCCESS', message: 'OK' })
  } catch (err) {
    console.error('支付回调处理失败:', err)
    res.status(500).json({ code: 'FAIL', message: err.message })
  }
})

module.exports = router
