const mongoose = require('mongoose')

const merchantSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, default: 'merchant' },
  name: { type: String, default: '' },
  phone: { type: String, default: '' }
}, { timestamps: true })

module.exports = mongoose.model('Merchant', merchantSchema)
